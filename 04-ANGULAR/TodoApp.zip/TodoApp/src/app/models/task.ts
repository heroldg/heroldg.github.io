export class Task {
  id: number;
  title: string;
  status = false;
}
